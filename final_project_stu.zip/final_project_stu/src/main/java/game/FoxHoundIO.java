package game;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Files;

public class FoxHoundIO {

    public static Boolean saveGame(String[] player, char fh, Path path) throws NullPointerException{
        //TODO: 2.6.1 Saving the Game
        return false;

    }

    public static char loadGame(String[] player, Path path) {
        //TODO: 2.6.2 Loading a Game
        return '#';
    }
}
